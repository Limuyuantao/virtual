# xform_utils
A library of utilities to convert among different object types, including
Eigen::Affine, geometry_msgs::Pose and tf

## Example usage
Use this library by including #include <xform_utils/xform_utils.h> and setting package
dependence on xform_utils in your package. Instantiate a XformUtils object to use the member fncs.

See object_finder package for example usage.
    